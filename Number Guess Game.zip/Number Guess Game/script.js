// var ranNum = Math.floor(Math.random()*20)+1;
// // console.log(ranNum);
// var numInput = document.getElementsById("guessNum");

// // document.getElementsByClassName("guess").addE
// document.getElementById("subNum").addEventListener("click",function(e) {
//     var numInput = parseInt(document.getElementById("guessNum").value);
//     if (ranNum==numInput)
//     {
//         alert("You Guessed It Right!!!");

//     }

//     else if (numInput>ranNum)
//     {
//         alert("Your Guess Is High!!!");
//     }
//     else{
//         alert("Your Guess Is Low!!!");
//     }


// }
// );
var counter = 20;
var inpNum = document.getElementById("inpNum");
var message = "";
var ranNum = Math.floor(Math.random() * 20) + 1;
console.log(ranNum);
// console.log(ranNum);
document.getElementById("subNum").addEventListener("click", function (e) {
    var inpNum = parseInt(document.getElementById("inpNum").value);

    if (inpNum == ranNum) {
        // message = "Success!";
        document.getElementById("msg").innerHTML = "Success!!!";
        document.getElementById("hscr").innerHTML = counter;
        document.getElementById("bodys").classList.remove("body-dark");
        document.getElementById("bodys").classList.add("body-success");
        

        // alert("Success!!!");
    }
    else if (inpNum < ranNum) {
        // alert("You are low!!!");
        document.getElementById("msg").innerHTML = "You are low!!";
        counter = counter - 1;
        document.getElementById("scr").innerHTML = counter;
    }
    else {
        // alert("You are high!!!");
        document.getElementById("msg").innerHTML = "You are high!!";
        counter = counter - 1;
        document.getElementById("scr").innerHTML = counter;
    }
    
    
});

document.getElementById("reset").addEventListener("click",function(c){
     counter=20;
     hscr=0;
     document.getElementById("hscr").innerHTML = hscr;
     document.getElementById("scr").innerHTML = counter;
     document.getElementById("msg").innerHTML = "";
     document.getElementById("inpNum").value="";   
     document.getElementById("bodys").classList.remove("body-success");
     document.getElementById("bodys").classList.add("body-dark");
     




});